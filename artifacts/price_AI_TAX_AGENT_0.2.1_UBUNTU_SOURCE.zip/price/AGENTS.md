# price: AI 세무사
Project and worker name are `price`; this is NOT a pricing/comparison product.
- Independent repository. Never write to CORP-OS or another workspace.
- Read docs/DEVELOPMENT_PLAN_KO.md and docs/IMPLEMENTATION_STATUS_KO.md before work.
- Tests: `python -m pytest -q`; API: `python -m price serve`; worker: `python -m price.worker --once`.
- All production filing/payment paths are fail-closed. Simulated receipts always carry sandbox labels.
- No claimed live LLM, legal validation, official returns, or remote deployment without actual evidence.
- Money is strict integer KRW; tax math uses Decimal. Never accept LLM-calculated totals as authoritative.
- Company scope, authenticated actor, independent approval, version/hash checks, and audit are mandatory.
- Preserve original evidence and posted journals; correct by a new reversal or new revision before posting.
- Never include real certificates, credentials, personal data, or generated session DBs in the deliverable.
- Do not commit, push, install a service, or expose a public port without an explicit request.
